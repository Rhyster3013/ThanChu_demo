using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Player : MonoBehaviour
{

    #region UI

    public bool isPickedAsTarget = false;
    public bool isPickable = false;

    #endregion

    // Initial stats
    public int Id { get; set; }         // Player id or number of order
    public int MaxHP { get; set; } = 4;
    public int HP = 4;         // Current HP
    public string Faction { get; set; }
    public int Status = 1;              // -1: Dying;    0: Dead;   1: Active;  2: Discarding or Responding
    public int stage = 6;               // Current stage of player, as in Draw, Action, Discard,...

    // Player limits
    public int limitHand;
    public int limitAttack = 1;
    public int limitCard = 1;

    // Alternative stats
    public int buff { get; set; } = 0;
    public int buffAttack { get; set; } = 0;

    // Player card
    public List<Deck> handCard;     // List of cards currently in hand
    public int numberOfCard;        // The number of cards currently in hand

    #region Timing

    // Card Timing
    // 1. Can dung the do duoc Lenh hoac trong giai doan Ra the
    public bool isNeedCard;	    // Enable usable Cards
    public bool isRespond;
    public bool isDiscard;

    // 3
    public List<Deck> AfterPickCard; // A list of picked cards
    public Deck AfterPick1Card;

    // 4 Show available targets and choose the amount of target as needed/available
    public List<Player> isPickTargets;
    public Player isPickTarget;

    // 5
    public Deck isUseCard;         // Confirm Using card

    // 6
    public List<Player> isTargetPlayer;	    // When targetting
    // 7
    public Deck isTargetted;	        // When being targetted, mostly passively
    // 8
    public bool isAfterTargetPlayer;	// After targetting
    // 9
    public Deck isAfterTargetted;      // After being targetted, mostly passively

    // Stage timing
    public bool isStageStart { get; set; } = true;      // Indicates if the player has a round
    public bool isStageJudge { get; set; } = false;     // If the player has a card in Judge Area
    public bool isStageDraw { get; set; } = true;       // If the player can draw
    public bool isStageAction { get; set; } = true;     // If the player can use cards in their turn
    public bool isStageDiscard { get; set; } = true;    // If the player needs to discard cards
    public bool isStageEnd { get; set; } = true;        // Indicates if it is about to begin another player's turn

    #endregion

    #region Buttons

    public bool isConfirm;
    public bool isCancel;

    #endregion
}
