using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using static Unity.VisualScripting.Member;

public class PlayerController : MonoBehaviour
{
    [SerializeField] Player currentPlayer;
    TimingController timingController;
    GameManager gameManager;
    [SerializeField] List<Deck> drawDeck = new List<Deck>();
    //[SerializeField] GameObject playerGO;

    public Transform areaHand;      // The GO Canvas in which Card prefabs will be generate into
    public GameObject cardPrefab;   // The Card prefab to view cards


    #region MonoBehaviour
    private void Start()
    {
        areaHand = transform.Find("HandCards").transform;
        cardPrefab = Resources.Load<GameObject>("Prefabs/Card");
        currentPlayer = GetComponent<Player>();
    }

    private void Update()
    {
        // Constantly updating the number of cards in hand
        currentPlayer.numberOfCard = currentPlayer.handCard.Count;

        // Constantly showing the cards in hand
        viewHandCards();
    }


    #endregion


    #region Gameplay
    public void loseHP(int dmg)
    {
        currentPlayer.HP -= dmg;
    }

    // Draw a numberToDraw from a source deck (drawing deck from Game Manager)
    public void DrawCard(int numberToDraw, List<Deck> source)
    {
        if (numberToDraw < source.Count)
        {
            for (int i = 0; i < numberToDraw; i++)
            {
                // Add cards from source to the handCard
                currentPlayer.handCard.Add(source[i]);
                source.Remove(source[i]);
            }
        }
        else
        {
            Debug.Log("Not enough cards");
        }
    }

    public void DrawCard(int drawFromDeck)
    {
        DeckManager deckManager = GameObject.Find("DrawDeck").GetComponent<DeckManager>();

        drawDeck = deckManager.randomDecks;
        //List<Deck> source;
        if (drawFromDeck < drawDeck.Count)
        {
            for (int i = 0; i < drawFromDeck; i++)
            {
                // Add cards from source to the handCard
                currentPlayer.handCard.Add(drawDeck[i]);
                drawDeck.Remove(drawDeck[i]);
            }
        }
        else
        {
            Debug.Log("Not enough cards");
        }
    }

    // Set all cards on hand to use
    public void ActiveHandCards()
    {
        timingController.TimingNeedCard(currentPlayer, areaHand);
    }

    #endregion


    #region UI

    public void viewHandCards()
    {
        foreach (Transform child in areaHand)
        {
            Destroy(child.gameObject);
        }

        // Repeate for each Deck in handCard
        for (int i = 0; i < currentPlayer.handCard.Count; i++)
        {
            getCardView(currentPlayer.handCard[i], i);
        }
    }

    public void getCardView(Deck card, int index)
    {
        GameObject cardView = Instantiate(cardPrefab, areaHand);

        setElement(cardView, card.Element, card.Number.ToString());
        setName(cardView, card.Name);

        cardView.name = "Card" + index;
    }

    // Set UI elements to the Card
    public void setElement(GameObject card, string element, string number)
    {
        Transform image = card.transform.Find("Element");
        Transform point = card.transform.Find("Element/Point");

        Image cardImage = image.GetComponent<Image>();
        TextMeshProUGUI cardPoint = point.GetComponent<TextMeshProUGUI>();

        cardPoint.text = number;

        switch (element)
        {
            case ("Fire"):
                cardImage.color = Color.red;
                cardPoint.color = Color.black;
                break;
            case ("Wind"):
                cardImage.color = Color.green;
                cardPoint.color = Color.black;
                break;
            case ("Water"):
                cardImage.color = Color.blue;
                cardPoint.color = Color.white;
                break;
            case ("Earth"):
                cardImage.color = Color.grey;
                cardPoint.color = Color.white;
                break;
        }
    }

    public void setName(GameObject card, string nameInput)
    {
        Transform name = card.transform.Find("Name");
        TextMeshProUGUI cardName = name.GetComponent<TextMeshProUGUI>();

        cardName.text = nameInput;
    }

    #endregion
}
