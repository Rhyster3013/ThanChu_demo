using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;
using static UnityEditor.Experimental.GraphView.GraphView;

public class GameManager : MonoBehaviour
{
    public List<PlayerController> playerList = new List<PlayerController>();
    public List<GameObject> playerGOList = new List<GameObject>();

    int roomSize = 2;
    [SerializeField] int playerIndex = 0;

    public UnityEngine.UI.Button btnStartGame;
    public UnityEngine.UI.Button btnNextStage;

    void Start()
    {
        MatchInitialize();

        btnStartGame = GameObject.Find("btnStartGame").GetComponent<UnityEngine.UI.Button>();
        btnStartGame.onClick.AddListener(GameStart);
        btnNextStage = GameObject.Find("btnNextStage").GetComponent<UnityEngine.UI.Button>();
    }


    #region Game Initialize
    private void GameStart()
    {
        btnStartGame.gameObject.SetActive(false);
        foreach (PlayerController player in playerList) { 
            player.DrawCard(4);
        }
        StartRoundForPlayer();
    }

    private void MatchInitialize()
    {
        setPlayerGO();
        getPlayerQueue();
    }

    public void NextPlayerTurn()
    {
        playerIndex++;
        if (playerIndex < playerList.Count)
        {
            StartRoundForPlayer(); // Start the next player's turn
        }
        else
        {
            playerIndex = 0;
        }
    }

    void StartRoundForPlayer()
    {
        if (playerIndex < playerList.Count)
        {
            Player currentPlayer = playerGOList[playerIndex].GetComponent<Player>();
            RoundController roundManager = currentPlayer.GetComponent<RoundController>();

            // Start the current player's turn and activate the button
            roundManager.RoundStart(btnNextStage);
        }
    }

    private void getPlayerQueue()
    {
        for (int i = 0; i < roomSize; i++)
        {
            string playerName = "Player" + i;
            playerList.Add(GetPlayerFromGO(playerName));
        }
    }

    private PlayerController GetPlayerFromGO(string playerName)
    {
        PlayerController player = GameObject.Find(playerName).GetComponent<PlayerController>();

        return player;
    }

    private void setPlayerGO()
    {
        for (int i = 0; i < roomSize; i++)
        {
            string playerName = "Player" + i;
            GameObject currentPlayerGO = GameObject.Find(playerName);

            Player player = currentPlayerGO.GetComponent<Player>();
            PlayerController playerController = currentPlayerGO.GetComponent<PlayerController>();
            RoundController roundController = currentPlayerGO.GetComponent<RoundController>();

            playerGOList.Add(currentPlayerGO);
            if (currentPlayerGO != null)
            {
                if (playerController == null)
                    currentPlayerGO.AddComponent<PlayerController>();
                if (player == null)
                    currentPlayerGO.AddComponent<Player>();
                if (roundController == null)
                    currentPlayerGO.AddComponent<RoundController>();
            }
        }
    }


    #endregion
}
