using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimingController : MonoBehaviour
{

    public void TimingNeedCard(Player player, Transform handCards)    
    {
        if (player.isNeedCard)
        {
            foreach (GameObject card in handCards)
            {
                if (card != null)
                {
                    CardActivate(card, true);
                }
            }
        }
    }

    public void CardActivate(GameObject card, bool isActive)
    {
        // Get CanvasGroup component of Card
        CanvasGroup canvasGroup = card.GetComponent<CanvasGroup>();

        if (canvasGroup == null)
        {
            // Add CanvasGroup if there is none
            canvasGroup = card.AddComponent<CanvasGroup>();
        }

        if (isActive)
        {
            // Enable the cards and allows interaction
            canvasGroup.alpha = 1f; // Opacity / Transparency
            canvasGroup.interactable = true; // interactable
            canvasGroup.blocksRaycasts = true; // Clickable
        }
        else
        {
            // Disable the cards and dont allow interaction
            canvasGroup.alpha = 0.5f; // Increase Opacity / Transparency
            canvasGroup.interactable = false; // not interactable
            canvasGroup.blocksRaycasts = false; // not clickable
        }
    }
}
