using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class RoundController : MonoBehaviour
{
    [SerializeField] Player currentPlayer;
    TimingController timingController;
    PlayerController playerController;
    GameObject playerGO;

    TextMeshProUGUI txbStageIndicator;

    [SerializeField] bool waitForNextStage = false;
    string[] Stages = new string[7] { "Start", "Judge", "Draw", "Action", "Discard", "End", "Outside" };
    [SerializeField] int currentStage = 7;

    #region Mono Behaviour
    // Start is called before the first frame update
    void Start()
    {
        currentPlayer = GetComponent<Player>();
        txbStageIndicator = transform.Find("txbStageIndicator").GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    #endregion

    public void RoundStart(Button btnNextState)
    {
        currentStage = 0; // Reset stage

        StageDefault();

        // Get button event from GameManager
        btnNextState.onClick.RemoveAllListeners(); // Delete previous event
        btnNextState.onClick.AddListener(ProceedToNextStage);

        scanStages();
    }

    // Wait for player to press button
    void WaitForPlayerAction()
    {
        waitForNextStage = true;
    }

    // Called when btnNextStage is pressed
    void ProceedToNextStage()
    {
        if (waitForNextStage)
        {
            currentStage++; // update current stage
            waitForNextStage = false; // reset flag
            scanStages(); // Continue to scan
        }
    }

    public void scanStages()
    {
        while (currentStage < 6)
        {
            switch (currentStage)
            {
                case 0:
                    if (currentPlayer.isStageStart)
                    {
                        UpdateStageIndicator(Stages[currentStage]);
                        WaitForPlayerAction();
                    }
                    else
                        currentStage = 5;
                    break;
                case 1:
                    if (currentPlayer.isStageJudge)
                    {
                        UpdateStageIndicator(Stages[currentStage]);
                        WaitForPlayerAction();
                    }
                    else
                        currentStage++;
                    break;
                case 2:
                    if (currentPlayer.isStageDraw)
                    {
                        UpdateStageIndicator(Stages[currentStage]);
                        playerController.DrawCard(2);
                        WaitForPlayerAction();
                    }
                    else
                        currentStage++;
                    break;
                case 3:
                    if (currentPlayer.isStageAction)
                    {
                        {
                            UpdateStageIndicator(Stages[currentStage]);
                            playerController.ActiveHandCards();
                            WaitForPlayerAction();
                        }
                    }
                    else
                        currentStage++;
                    break;
                case 4:
                    if (currentPlayer.isStageDiscard)
                    {
                        UpdateStageIndicator(Stages[currentStage]);
                        WaitForPlayerAction();
                    }
                    else
                        currentStage++;
                    break;
                case 5:
                    if (currentPlayer.isStageEnd)
                    {
                        UpdateStageIndicator(Stages[currentStage]);
                        WaitForPlayerAction();
                    }
                    else
                        currentStage++;
                    break;
            }
        }
        if (currentStage == 7)
        {
            UpdateStageIndicator(Stages[currentStage]);
        }
    }

    void UpdateStageIndicator(string currentStage)
    {
        txbStageIndicator.text = currentStage;
    }

    void StageDefault()
    {
        currentPlayer.isStageStart = true;
        currentPlayer.isStageEnd = true;

        currentPlayer.isStageJudge = false;
        currentPlayer.isStageDraw = true;
        currentPlayer.isStageDiscard = true;
    }
}
